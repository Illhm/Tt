| seq | method | status | mime | size | url |
|---:|:--|:--:|:--|--:|:--|
| 12 | GET | 200 | application/javascript | 0 | https://ssstik.io/js/script_ssstik.min.js?v=2025dec03.1 |
| 13 | GET | 200 | text/javascript | 3695 | chrome-extension://cjpalhdlnbpafiamejdnhcphjbkeiagm/web_accessible_resources/google-analytics_analytics.js?secret=xz55hz |
| 14 | GET | 200 | text/javascript | 3694 | chrome-extension://cjpalhdlnbpafiamejdnhcphjbkeiagm/web_accessible_resources/googlesyndication_adsbygoogle.js?secret=xcskwf |
| 24 | GET | 200 | text/plain | 381 | https://ssstik.io/cdn-cgi/trace |
| 25 | POST | 200 | text/html | 3776 | https://ssstik.io/abc?url=dl |
